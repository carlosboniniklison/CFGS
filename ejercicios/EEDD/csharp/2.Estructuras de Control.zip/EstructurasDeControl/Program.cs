﻿using System;

/****************************************
 * Autor: Alberto Laorden Peñalver
 * Curso: 1DAM-M
 * Asignación: Estructuras de Control
 * Fecha asignación: 12 febrero
 ***************************************/

namespace EstructurasDeControl
{
    class Program
    {
        static void Main(string[] args) { 
        int numero;             //Declaración de variables
        int contador = 0;
        int contadorImpar = 0;
        int multiplicador = 1;

        Random random = new Random(); //Instanciamos un generador de 
                                      //números aleatorios que usaremos más tarde.

        Console.WriteLine("Introduzca cuántos números quiere generar:");
        numero = int.Parse(Console.ReadLine());
        
        Console.WriteLine("Los números aleatorios son:");
            Console.WriteLine("");
            Console.WriteLine("");
            for (int i = 0; i<numero; i++) //Bucle que itera hasta llegar al número de aleatorios introducido.
            {
                int randomNumber = random.Next(0, 100); //Numeros aleatorios del 1 al 100.
        Console.WriteLine(randomNumber);
                if ((randomNumber % 2) == 0) //Almacenamos y sacamos por pantalla los pares.
                {
                    Console.WriteLine("Es par.");
                    contador++;

            }
                else { 
        Console.WriteLine("Es impar."); //Almacenamos y sacamos por pantalla los impares.
                    contadorImpar++;
                
            }
            }

            for (int i = 1; i <= contador; i++)
            {
                multiplicador = multiplicador* (i * 2);
            }
            Console.WriteLine("");
            Console.WriteLine("Han salido: " + contador + " numeros pares.");
            Console.WriteLine("Han salido: " + contadorImpar + " numeros impares.");
            Console.WriteLine("El producto de los "+contador+" primeros números pares es: "+multiplicador);
        }
        }
    }