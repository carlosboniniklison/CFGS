﻿using System;

/****************************************
 * Autor: Alberto Laorden Peñalver
 * Curso: 1DAM-M
 * Asignación: Ejercicio de condiciones compuestas 
 * Fecha asignación: 5 de febrero
 ***************************************/


namespace CondicionalesTrimestre
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            
            String mes; //Declaramos la variable.


            Console.WriteLine("Introduzca un mes y el programa le dirá si pertenece al primer trimestre.");
            mes = Console.ReadLine();


            if (mes == "enero" || mes == "febrero" || mes == "marzo" || mes == "Enero" || mes == "Febrero" ||
                mes == "Marzo") // Usamos el operador “||” para indicar que vale cualquiera de los tres.
            {
                Console.WriteLine("El mes de " + mes + " SI pertenece al primer trimestre del Año. ");
            }
            else //Si no es ninguno de esos tres, lanza el mensaje a continuación
            {
                Console.WriteLine("El mes introducido NO pertenece al primer trimestre del año");
            }


        }
    }
}
