﻿using System;

/****************************************
 * Autor: Alberto Laorden Peñalver
 * Curso: 1DAM-M
 * Asignación: Operación matemática en Csharp
 * Fecha asignación: 19 de febrero
 ***************************************/

namespace whatever
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduzca un número:");
            String n1 = Console.ReadLine();
            int numero1 = int.Parse(n1);

            Console.WriteLine("Introduzca uno de los operadores siguientes:  [ + | - | * | / | % ]");

            String operador = Console.ReadLine();



            Console.WriteLine("Introduzca otro número:");
            String n2 = Console.ReadLine();
            int numero2 = int.Parse(n2);
            
            Boolean comprobar; //De esta manera comprobamos que lo que introducimos sean números.

            try
            {
                Int32.Parse(n1);
                Int32.Parse(n2);
                comprobar = true;
            }
            catch
            {
                comprobar = false;
            }

            if (comprobar)
            {
                int n1_prueba = int.Parse(n1);
                int n2_prueba = int.Parse(n2);
                switch (operador)
                {

                    case "+":

                        Console.WriteLine("El resultado es: " + (numero1 + numero2));
                        break;

                    case "-":
                        Console.WriteLine("El resultado es: " + (numero1 - numero2));
                        break;

                    case "*":
                        Console.WriteLine("El resultado es: " + (numero1 * numero2));
                        break;

                    case "/":
                        Console.WriteLine("El resultado es: " + (numero1 / numero2));
                        break;

                    case "%":
                        Console.WriteLine("El resto es: " + (numero1 % numero2));
                        break;

                    default:
                        Console.WriteLine("No ha metido un operador correcto.");
                        break;

                }
            }
        }
    }
}
