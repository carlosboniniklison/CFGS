﻿using System;

/****************************************
 * Autor: Alberto Laorden Peñalver
 * Curso: 1DAM-M
 * Asignación: Pintando la Consola
 * Fecha asignación: 11 de marzo
 ***************************************/

namespace PintandoLaConsola
{
    class Program
    {
        protected static int Columnas;
        protected static int Filas;


        protected static void WriteAt(ConsoleColor[] colors)
        {
            try
            {
                Random r = new Random();
                int randomChar = r.Next(5);
                char[] arrayChar = { (char)33, (char)34, (char)35, (char)36, (char)37 };

                int colorDeFrente = r.Next(16); //Aquí tenemos el total de colores.
                int colorFondo = r.Next(16); //Aquí el total de colores del fondo.

                int posX = r.Next(80); //Declaramos 80 columnas.
                int posY = r.Next(24); //Y aquí las 24 filas.

                Console.SetCursorPosition(Columnas + posX, Filas + posY); //Posiciones en las que se imprime.          
                Console.ForegroundColor = colors[colorDeFrente]; //Color de los caracteres enfrentados al fondo.
                Console.BackgroundColor = colors[colorFondo]; //Color del fondo de la consola.
                Console.Write(arrayChar[randomChar]); //Impresion de caracteres aleatorios del array declarado previamente como "arrayChar"

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }


        public static void Main()
        {

            ConsoleColor[] colours = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor));

            ConsoleColor currentBackground = Console.BackgroundColor;
            ConsoleColor currentForeground = Console.ForegroundColor;

            Columnas = Console.CursorTop;
            Filas = Console.CursorLeft;


            for (int i = 0; i < 3000; i++) //Con este bucle pintamos la consola.
            {
                WriteAt(colours);
            }

            Console.SetCursorPosition(Columnas + 80, Filas + 24);
            Console.ResetColor();

        }


    }
}