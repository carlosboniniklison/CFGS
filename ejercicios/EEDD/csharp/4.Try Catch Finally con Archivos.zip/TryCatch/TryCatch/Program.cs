﻿using System;

/****************************************
 * Autor: Alberto Laorden Peñalver
 * Curso: 1DAM-M
 * Asignación: Try-Catch Finally con ficheros
 * Fecha asignación: 4 de marzo
 ***************************************/

namespace TryCatch
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = 0; //Declaración de variables
            string line;

            // Read the file and display it line by line.
            //La raiz dada es a mi ordenador, haría falta cambiarla a un archivo existente en el ordenador donde se realice la corrección.
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\34606\34606despues.txt");

            try
            {


                while ((line = file.ReadLine()) != null)
                {
                    System.Console.WriteLine(line);
                    counter++;
                }


            }
            catch (Exception e)
            {
                file.Close();
                Environment.Exit(99);
            }

            while ((line = file.ReadLine()) != null)
            {
                System.Console.WriteLine(line);
                counter++;
            }



            file.Close();
            System.Console.WriteLine("There were {0} lines.", counter);
            // Suspend the screen.
            System.Console.ReadLine();

            int[] arrayNumeros = new int[5];


            Console.WriteLine("Introduzca 10 numeros entre 1 y 99.");

            for (int i = 0; i < 5; i++)
            {

                arrayNumeros[i] = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduzca otro número:");

            }

            // Ordenamos el array de forma ascendente.
            Console.Write("Aquí ordenamos el array de forma ascendente: ");
            Array.Sort(arrayNumeros);

            foreach (int i in arrayNumeros) Console.Write(i + " ");

            Console.WriteLine("");


            // Y aquí de forma descendente. 
            Console.Write("Aquí ordenamos el array de forma descendente: ");
            Array.Reverse(arrayNumeros);

            foreach (int i in arrayNumeros) Console.Write(i + " ");
        }
    }
}
